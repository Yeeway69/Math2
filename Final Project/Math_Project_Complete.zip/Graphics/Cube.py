class Cube:
    def __init__(self):
        # TODO: Initialize the Cube
        pass

    def update(self):
        # TODO: Update cube's state
        pass